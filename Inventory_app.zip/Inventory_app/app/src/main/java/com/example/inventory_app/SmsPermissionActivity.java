package com.example.inventory_app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class SmsPermissionActivity extends AppCompatActivity {

    private TextView statusText;
    private TextView resultTitle;
    private TextView resultMessage;
    private TextView previewMessage;
    private TextInputEditText phoneNumberField;
    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        statusText = findViewById(R.id.permissionStatusText);
        resultTitle = findViewById(R.id.permissionResultTitle);
        resultMessage = findViewById(R.id.permissionResultMessage);
        previewMessage = findViewById(R.id.previewMessage);
        phoneNumberField = findViewById(R.id.phoneNumberField);

        MaterialButton requestButton = findViewById(R.id.requestSmsPermissionButton);
        MaterialButton denyButton = findViewById(R.id.denySmsButton);

        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    // Keep the rest of the app working either way.
                    updatePermissionState(isGranted);
                    if (isGranted) {
                        sendLowInventoryAlert();
                    }
                }
        );

        requestButton.setOnClickListener(v -> requestSmsPermission());
        denyButton.setOnClickListener(v -> updateDeniedState());

        refreshState();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            updatePermissionState(true);
            sendLowInventoryAlert();
            return;
        }
        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private void refreshState() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        updatePermissionState(granted);
    }

    private void updatePermissionState(boolean granted) {
        if (granted) {
            statusText.setText(R.string.sms_granted_title);
            resultTitle.setText(R.string.sms_granted_title);
            resultMessage.setText(R.string.sms_granted_message);
            previewMessage.setText(R.string.sms_preview_ready);
        } else {
            updateDeniedState();
        }
    }

    private void updateDeniedState() {
        statusText.setText(R.string.sms_denied_title);
        resultTitle.setText(R.string.sms_denied_title);
        resultMessage.setText(R.string.sms_denied_message);
        previewMessage.setText(R.string.sms_preview_denied);
    }

    private void sendLowInventoryAlert() {
        String phoneNumber = readText(phoneNumberField);
        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Enter a phone number before sending an SMS.", Toast.LENGTH_SHORT).show();
            previewMessage.setText(R.string.sms_preview_missing_number);
            return;
        }

        String alertMessage = getString(R.string.sms_alert_message);
        try {
            SmsManager smsManager = getSystemService(SmsManager.class);
            if (smsManager == null) {
                throw new IllegalStateException("SMS service is unavailable.");
            }
            smsManager.sendTextMessage(phoneNumber, null, alertMessage, null, null);
            previewMessage.setText(getString(R.string.sms_preview_sent, phoneNumber));
        } catch (Exception exception) {
            previewMessage.setText(R.string.sms_preview_failed);
            Toast.makeText(this, "The message could not be sent on this device.", Toast.LENGTH_SHORT).show();
        }
    }

    private String readText(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
