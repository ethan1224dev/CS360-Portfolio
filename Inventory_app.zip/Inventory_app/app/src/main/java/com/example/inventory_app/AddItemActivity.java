package com.example.inventory_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class AddItemActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM_ID = "extra_item_id";

    private InventoryDatabaseHelper databaseHelper;
    private TextInputEditText itemNameField;
    private TextInputEditText skuField;
    private TextInputEditText quantityField;
    private TextInputEditText locationField;
    private TextInputEditText categoryField;
    private long itemId = -1L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        databaseHelper = new InventoryDatabaseHelper(this);
        itemNameField = findViewById(R.id.itemNameField);
        skuField = findViewById(R.id.skuField);
        quantityField = findViewById(R.id.quantityField);
        locationField = findViewById(R.id.locationField);
        categoryField = findViewById(R.id.categoryField);

        MaterialButton saveButton = findViewById(R.id.saveItemButton);
        MaterialButton cancelButton = findViewById(R.id.cancelItemButton);

        itemId = getIntent().getLongExtra(EXTRA_ITEM_ID, -1L);
        if (itemId > 0) {
            // Editing an existing row should prefill the form.
            populateFields(itemId);
            saveButton.setText(R.string.update_button);
        }

        saveButton.setOnClickListener(v -> saveItem());

        cancelButton.setOnClickListener(v -> finish());
    }

    private void populateFields(long id) {
        InventoryItem item = databaseHelper.getItem(id);
        if (item == null) {
            return;
        }

        itemNameField.setText(item.getName());
        skuField.setText(item.getSku());
        quantityField.setText(String.valueOf(item.getQuantity()));
        locationField.setText(item.getLocation());
        categoryField.setText(item.getCategory());
    }

    private void saveItem() {
        String name = readText(itemNameField);
        String sku = readText(skuField);
        String quantityText = readText(quantityField);
        String location = readText(locationField);
        String category = readText(categoryField);

        if (name.isEmpty() || sku.isEmpty() || quantityText.isEmpty() || location.isEmpty() || category.isEmpty()) {
            Toast.makeText(this, "Fill in every field before saving.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException exception) {
            Toast.makeText(this, "Quantity needs to be a whole number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // A zero id means this is a new row instead of an edit.
        long savedId = databaseHelper.saveItem(new InventoryItem(itemId, name, sku, quantity, location, category));
        if (savedId == -1) {
            Toast.makeText(this, "Item could not be saved.", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, itemId > 0 ? "Item updated." : "Item added.", Toast.LENGTH_SHORT).show();
        finish();
    }

    private String readText(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
