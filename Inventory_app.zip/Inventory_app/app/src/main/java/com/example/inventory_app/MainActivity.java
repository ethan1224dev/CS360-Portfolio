package com.example.inventory_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_USERNAME = "extra_username";

    private InventoryDatabaseHelper databaseHelper;
    private TextInputEditText usernameField;
    private TextInputEditText passwordField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new InventoryDatabaseHelper(this);
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);

        MaterialButton loginButton = findViewById(R.id.loginButton);
        MaterialButton createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(v -> handleLogin());
        createAccountButton.setOnClickListener(v -> handleCreateAccount());
    }

    private void handleLogin() {
        String username = getFieldValue(usernameField);
        String password = getFieldValue(passwordField);

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter both a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.authenticateUser(username, password)) {
            openInventoryScreen(username);
            return;
        }

        Toast.makeText(this, "Login failed. Create an account first if needed.", Toast.LENGTH_SHORT).show();
    }

    private void handleCreateAccount() {
        String username = getFieldValue(usernameField);
        String password = getFieldValue(passwordField);

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and password are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        // New users can create their login from the same screen.
        if (!databaseHelper.createUser(username, password)) {
            Toast.makeText(this, "That username already exists.", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Account created.", Toast.LENGTH_SHORT).show();
        openInventoryScreen(username);
    }

    private void openInventoryScreen(String username) {
        Intent intent = new Intent(this, InventoryActivity.class);
        intent.putExtra(EXTRA_USERNAME, username);
        startActivity(intent);
    }

    private String getFieldValue(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
