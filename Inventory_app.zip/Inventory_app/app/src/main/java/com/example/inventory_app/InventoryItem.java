package com.example.inventory_app;

public class InventoryItem {

    private final long id;
    private final String name;
    private final String sku;
    private final int quantity;
    private final String location;
    private final String category;

    public InventoryItem(long id, String name, String sku, int quantity, String location, String category) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.quantity = quantity;
        this.location = location;
        this.category = category;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSku() {
        return sku;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getLocation() {
        return location;
    }

    public String getCategory() {
        return category;
    }

    public boolean isLowStock() {
        return quantity <= 10;
    }
}
