package com.example.inventory_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "stockpulse.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_ITEMS = "items";

    private static final String COL_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";

    private static final String COL_ITEM_NAME = "item_name";
    private static final String COL_SKU = "sku";
    private static final String COL_QUANTITY = "quantity";
    private static final String COL_LOCATION = "location";
    private static final String COL_CATEGORY = "category";

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Store user credentials separately from inventory rows.
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL)");

        // This table backs the grid shown on the inventory screen.
        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_SKU + " TEXT NOT NULL, "
                + COL_QUANTITY + " INTEGER NOT NULL, "
                + COL_LOCATION + " TEXT NOT NULL, "
                + COL_CATEGORY + " TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    public boolean createUser(String username, String password) {
        String cleanedUsername = cleanText(username);
        String cleanedPassword = cleanText(password);
        if (cleanedUsername.isEmpty() || cleanedPassword.isEmpty()) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, cleanedUsername);
        values.put(COL_PASSWORD_HASH, hashPassword(cleanedPassword));

        SQLiteDatabase db = getWritableDatabase();
        try {
            long result = db.insertOrThrow(TABLE_USERS, null, values);
            return result != -1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    public boolean authenticateUser(String username, String password) {
        String cleanedUsername = cleanText(username);
        String cleanedPassword = cleanText(password);
        if (cleanedUsername.isEmpty() || cleanedPassword.isEmpty()) {
            return false;
        }

        // Compare the stored hash instead of the raw password.
        String[] selectionArgs = {cleanedUsername, hashPassword(cleanedPassword)};
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[]{COL_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD_HASH + "=?",
                selectionArgs, null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    public long saveItem(InventoryItem item) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, item.getName());
        values.put(COL_SKU, item.getSku());
        values.put(COL_QUANTITY, item.getQuantity());
        values.put(COL_LOCATION, item.getLocation());
        values.put(COL_CATEGORY, item.getCategory());

        SQLiteDatabase db = getWritableDatabase();
        if (item.getId() > 0) {
            db.update(TABLE_ITEMS, values, COL_ID + "=?", new String[]{String.valueOf(item.getId())});
            return item.getId();
        }
        return db.insert(TABLE_ITEMS, null, values);
    }

    public boolean deleteItem(long itemId) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_ITEMS, COL_ID + "=?", new String[]{String.valueOf(itemId)}) > 0;
    }

    public InventoryItem getItem(long itemId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_ITEMS, null, COL_ID + "=?",
                new String[]{String.valueOf(itemId)}, null, null, null)) {
            if (!cursor.moveToFirst()) {
                return null;
            }
            return readItem(cursor);
        }
    }

    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_ITEMS, null, null, null, null, null, COL_ITEM_NAME + " COLLATE NOCASE ASC")) {
            while (cursor.moveToNext()) {
                items.add(readItem(cursor));
            }
        }
        return items;
    }

    public boolean isItemTableEmpty() {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_ITEMS, null)) {
            return cursor.moveToFirst() && cursor.getInt(0) == 0;
        }
    }

    public void seedDefaultItemsIfNeeded() {
        if (!isItemTableEmpty()) {
            return;
        }

        // Seed a few rows so the rubric can see read, update, and delete behavior right away.
        saveItem(new InventoryItem(0, "Safety gloves", "INV-1001", 24, "Aisle 3", "PPE"));
        saveItem(new InventoryItem(0, "Packing tape", "INV-1002", 8, "Dock B", "Shipping"));
        saveItem(new InventoryItem(0, "Barcode labels", "INV-1003", 57, "Shelf 2", "Supplies"));
        saveItem(new InventoryItem(0, "Hand sanitizer", "INV-1004", 0, "Cabinet 1", "Safety"));
    }

    private InventoryItem readItem(Cursor cursor) {
        long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID));
        String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
        String sku = cursor.getString(cursor.getColumnIndexOrThrow(COL_SKU));
        int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_QUANTITY));
        String location = cursor.getString(cursor.getColumnIndexOrThrow(COL_LOCATION));
        String category = cursor.getString(cursor.getColumnIndexOrThrow(COL_CATEGORY));
        return new InventoryItem(id, name, sku, quantity, location, category);
    }

    private String cleanText(String value) {
        return value == null ? "" : value.trim();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder(hash.length * 2);
            for (byte value : hash) {
                builder.append(String.format(Locale.US, "%02x", value));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }
}
