package com.example.inventory_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "stockpulse_prefs";
    private static final String PREF_SAMPLE_DATA_LOADED = "sample_data_loaded";

    private InventoryDatabaseHelper databaseHelper;
    private GridLayout inventoryGrid;
    private TextView emptyStateText;
    private TextView welcomeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new InventoryDatabaseHelper(this);
        inventoryGrid = findViewById(R.id.inventoryGrid);
        emptyStateText = findViewById(R.id.emptyStateText);
        welcomeText = findViewById(R.id.welcomeText);

        MaterialButton addItemButton = findViewById(R.id.addItemButton);
        MaterialButton smsButton = findViewById(R.id.smsButton);

        String username = getIntent().getStringExtra(MainActivity.EXTRA_USERNAME);
        if (username != null && !username.isEmpty()) {
            welcomeText.setText(getString(R.string.inventory_welcome, username));
        }

        addItemButton.setOnClickListener(v -> startActivity(new Intent(this, AddItemActivity.class)));
        smsButton.setOnClickListener(v -> startActivity(new Intent(this, SmsPermissionActivity.class)));

        ensureSampleDataLoaded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderInventory();
    }

    private void ensureSampleDataLoaded() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if (preferences.getBoolean(PREF_SAMPLE_DATA_LOADED, false)) {
            return;
        }

        // Load starter rows once so the grid is not empty on first launch.
        databaseHelper.seedDefaultItemsIfNeeded();
        preferences.edit().putBoolean(PREF_SAMPLE_DATA_LOADED, true).apply();
    }

    private void renderInventory() {
        List<InventoryItem> items = databaseHelper.getAllItems();
        inventoryGrid.removeAllViews();

        if (items.isEmpty()) {
            // Show a simple empty state instead of a blank screen.
            emptyStateText.setVisibility(View.VISIBLE);
            return;
        }

        emptyStateText.setVisibility(View.GONE);
        for (InventoryItem item : items) {
            inventoryGrid.addView(createItemCard(item));
        }
    }

    private MaterialCardView createItemCard(InventoryItem item) {
        MaterialCardView card = new MaterialCardView(this);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        card.setLayoutParams(params);
        card.setCardBackgroundColor(getColor(R.color.mist_50));
        card.setRadius(dpToPx(18));
        card.setStrokeColor(getColor(R.color.mist_100));
        card.setStrokeWidth(1);
        card.setUseCompatPadding(true);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int padding = dpToPx(16);
        container.setPadding(padding, padding, padding, padding);

        TextView nameView = new TextView(this);
        nameView.setText(item.getName());
        nameView.setTextColor(getColor(R.color.ink_950));
        nameView.setTextSize(16f);
        nameView.setTypeface(nameView.getTypeface(), android.graphics.Typeface.BOLD);

        TextView skuView = new TextView(this);
        skuView.setText(getString(R.string.item_sku_label, item.getSku()));
        skuView.setTextColor(getColor(R.color.teal_600));
        skuView.setTextSize(12f);

        TextView quantityView = new TextView(this);
        quantityView.setText(getString(R.string.item_quantity_label, item.getQuantity()));
        quantityView.setTextColor(item.isLowStock() ? getColor(R.color.coral_400) : getColor(R.color.teal_600));
        quantityView.setTextSize(14f);
        quantityView.setTypeface(quantityView.getTypeface(), android.graphics.Typeface.BOLD);

        TextView locationView = new TextView(this);
        locationView.setText(getString(R.string.item_location_label, item.getLocation()));
        locationView.setTextColor(getColor(R.color.slate_700));
        locationView.setTextSize(13f);

        TextView categoryView = new TextView(this);
        categoryView.setText(getString(R.string.item_category_label, item.getCategory()));
        categoryView.setTextColor(getColor(R.color.slate_700));
        categoryView.setTextSize(13f);

        LinearLayout buttonRow = new LinearLayout(this);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        buttonRow.setPadding(0, dpToPx(12), 0, 0);

        MaterialButton editButton = new MaterialButton(this);
        editButton.setText(R.string.edit_button);
        editButton.setAllCaps(false);
        editButton.setCornerRadius(dpToPx(14));

        MaterialButton deleteButton = new MaterialButton(this);
        deleteButton.setText(R.string.delete_button);
        deleteButton.setAllCaps(false);
        deleteButton.setCornerRadius(dpToPx(14));
        deleteButton.setTextColor(getColor(R.color.coral_400));

        LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        editParams.setMarginEnd(dpToPx(10));
        editButton.setLayoutParams(editParams);
        deleteButton.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        editButton.setOnClickListener(v -> openEditScreen(item.getId()));
        deleteButton.setOnClickListener(v -> {
            if (databaseHelper.deleteItem(item.getId())) {
                Toast.makeText(this, item.getName() + " deleted.", Toast.LENGTH_SHORT).show();
                renderInventory();
            }
        });

        buttonRow.addView(editButton);
        buttonRow.addView(deleteButton);

        container.addView(nameView);
        container.addView(skuView);
        container.addView(quantityView);
        container.addView(locationView);
        container.addView(categoryView);
        container.addView(buttonRow);

        card.addView(container);
        return card;
    }

    private void openEditScreen(long itemId) {
        Intent intent = new Intent(this, AddItemActivity.class);
        intent.putExtra(AddItemActivity.EXTRA_ITEM_ID, itemId);
        startActivity(intent);
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
